"""TypingTestGame"""

__author__ = "Yogesh Barai"
__version__ = "0.0.1"