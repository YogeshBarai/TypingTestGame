"""TypingTestGame"""

__author__ = "Yogesh Barai"
__version__ = "1.1.0"