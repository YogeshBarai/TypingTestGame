import TypingTestAppV2

if __name__ == "__main__":
    OBJ = TypingTestAppV2.TypingTestAppV2()
    OBJ.run()
    