"""TypingTestGame"""

__author__ = "Yogesh Barai"
__version__ = "1.0.0"